// import React from 'react';
// import './MainContent.css'
// import { Outlet } from 'react-router-dom';
// const MainContent: React.FC = (children:any) => {
//   return <main className="main-content">
//    <Outlet/>
//     </main>;
// };

// export default MainContent;